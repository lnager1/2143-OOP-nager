/*

1) Dice (Rolls multiple die, need diffrent modes for final result)
-> modes: Standard, Average, Bestof, addition, subtraction

2) Weapon class (generated using a config file)
- attackValue
Fists & Feet (1.d.4 OR 1.d.6)
Sword (1.d.12 OR 2.d.6 OR 3.d.4)
Bow (1.d.8 OR 2.d.4 OR 1.d.10)
Magic Spell (1.d.20 OR 2.d.10 OR 3.d.6 OR 5.d.4)
Magic Weapon (Add 1.d.4 OR 1.d.6 to primary weapon)
Fire Weapon (Add 1.d.6 OR 1.d.8 to primary weapon)

3) Attacker(s) are bad guys (how many and what kind are generated from a file)
Attackers are their own class having
-hitPoints (How many points until expiration)
-attackStrength (Points damage against who they are fighting)
-recoveryStrength (regains x number of hit points per round)

4) Defender(s) are good guys (made dependng on how many attackers there are)
BaseFighter is our parents of both:
-Name : string
-HP : Health points (random from 3 - 8)
-RR : Regeneration Rate (random from .15 - .75)
-PW : Primary Weapon = Fists and Feet
Subclasses of BaseFighter:
Warrior (uses sword)
Wizard (uses magic)
Archer (uses bow)
Elf: (uses magic + sword)
DragonBorn: (uses bow + fire)

5) Main logic rules:
Attacking force (bad guys) is any size
Defending force (good guys) 1 of each character type for every 100 attackers
Attacking force heals only in battle
Defending Force can heal any time
Characters die at 0 hp duh
Defending force can swap out characters in the middle of battle when it is their turn to attack. This will be used in place of an attack.
Game ends when one of the two queues (attackers or defenders) is empty

6) Need to print running commentary to std::out describing what is happening
Example: 
Wizard Attacks Dragonborn for 13 damage (dragon has 0 hp remaining)
DragonBorn Born has perished.
Defenders send out Wizard

Output notes:
Enemies are controled by a bad guy named "Captain Base"
*/

#include<iostream>
#include <stdlib.h>
#include <string>
#include <vector>
#include <time.h>

class Die 
{
	int sides;
public:
	//Both allows for passing in and default construction
	Die(int sidesIn = 6)
    {
		sides = sidesIn;
	}
	int roll(int rolls = 1) 
    {
			int sum = 0;
			while(rolls--)
            {
				sum += (std::rand() % sides) + 1;
			}
			return sum;
	};

	friend std::ostream& operator<<(std::ostream &os, const Die& d)
    {
			return os << "[" << d.sides << "]";
	}
};

/*Specified that it needed to be able to Standard, Average, Bestof, addition, subtraction on a single set type of dice
Options are:
Letter at the start denoting
-> Average (a)
-> Best of (b)
-> Standard ()

and number, d then number for number of dice then number of faces
XdX

lastly plus followed by a number
+X

Example string = "b12d6+16"

So Mode-Dice-Addition
*/
class Dice
{
	public:
    std::string setString;

	Dice(std::string diceString = "1d6")
    {
		setString = diceString;
	}
	int roll()
    {
		int index = 0;
		char mode = 's';
		//check if non-standard mode
		if(setString[0] == 'a' || setString[0] == 'b')
        {
			mode = setString[0];
			index = 1;
		}
		//grab dice
		std::string count = "0", sides = "0", base = "0";
		while(setString[index] != 'd' && index < setString.size())
        {
			count += setString[index];
			index++;
		}
		index++;
		while(setString[index] != '+' && index < setString.size())
        {
			sides += setString[index];
			index++;
		}
		index++;
		while(index < setString.size())
        {
			base += setString[index];
			index++;
		}
		if(mode == 'a')
        {
			return average(std::stoi(count), std::stoi(sides), std::stoi(base));
		} 
        else if(mode == 'b')
        {
			return bestOf(std::stoi(count), std::stoi(sides), std::stoi(base));
		} 
        else 
        {
			return standard(std::stoi(count), std::stoi(sides), std::stoi(base));
		}
	}

	int standard(int count,int sides,int base)
    {
		int result = 0;
		for(int i = 0; i < count; i++)
        {
			result += (std::rand() % sides) + 1;
		}
		return result + base;
	}
	int average(int count,int sides,int base)
    {
		int result = 0;
		for(int i = 0; i < count; i++)
        {
			result += (std::rand() % sides) + 1;
		}
		return (result / count) + base;
	}
	int bestOf(int count,int sides,int base)
    {
		int result = 0;
		for(int i = 0; i < count; i++)
        {
			int dieRoll = (std::rand() % sides) + 1;
			if(result < dieRoll)
            { 
				result = dieRoll;
			}
		}
		return result + base;
	}
    const Dice operator+(Dice rhs)
    {
        std::string newDiceString;
        Dice returnVal;

        newDiceString = setString + "+" + std::to_string(rhs.roll());

        returnVal = Dice(newDiceString);
    }
};

class Weapon
{
    public:
        Weapon()
        {
            int useRand = rand()%2;

            if(useRand)
            {
                attackValue = Dice("1d6");
            }
            else
            {
                attackValue = Dice("1d4");
            }
        }
    
    Dice attackValue;
};

class Sword : public Weapon
{
    public:
        Sword()
        {
            int useRand = rand()%3;
            
            if(useRand == 2)
            {
                attackValue = Dice("3d4");
            }
            else if(useRand == 1)
            {
                attackValue = Dice("2d6");
            }
            else
            {
                attackValue = Dice("1d12");
            }
        }
    
};

class Bow : public Weapon
{
    public:
        Bow()
        {
            int useRand = rand()%3;
            
            if(useRand == 2)
            {
                attackValue = Dice("1d8");
            }
            else if(useRand == 1)
            {
                attackValue = Dice("2d4");
            }
            else
            {
                attackValue = Dice("1d10");
            }
        }
    
};

class MagicSpell : public Weapon
{
    public:
        MagicSpell()
        {
            int useRand = rand()%4;
            
            if(useRand == 3)
            {
                attackValue = Dice("1d20");
            }
            else if(useRand == 2)
            {
                attackValue = Dice("2d10");
            }
            else if(useRand == 1)
            {
                attackValue = Dice("3d6");
            }
            else
            {
                attackValue = Dice("5d4");
            }
        }
};

class MagicWeapon : public Weapon
{
    public:
        MagicWeapon()
        {
            int useRand = rand()%2;

            if(useRand)
            {
                attackValue = Dice("1d6");
            }
            else
            {
                attackValue = Dice("1d4");
            }
        }
};

class FireWeapon : public Weapon 
{
    public:
        FireWeapon()
        {
            int useRand = rand()%2;

            if(useRand)
            {
                attackValue = Dice("1d6");
            }
            else
            {
                attackValue = Dice("1d8");
            }
        }
};

class MagicSword : public Sword, public MagicWeapon
{
     public:
        MagicSword()
        {
            int useRand = rand()%2;

            Weapon::attackValue = Sword::attackValue + MagicWeapon::attackValue;
        }
};

class FireSword : public Sword, public FireWeapon
{
     public:
        FireSword()
        {
            int useRand = rand()%2;

            Weapon::attackValue = Sword::attackValue + FireWeapon::attackValue;
        }
};

class MagicBow : public Bow, public MagicWeapon
{
     public:
        MagicBow()
        {
            int useRand = rand()%2;

            Weapon::attackValue = Bow::attackValue + MagicWeapon::attackValue;
        }
};

class FireBow : public Bow, public FireWeapon
{
     public:
        FireBow()
        {
            int useRand = rand()%2;

            Weapon::attackValue = Bow::attackValue + FireWeapon::attackValue;
            std::cout << Weapon::attackValue.setString;
        }
};

int main()
{
	std::srand (time(NULL));
	Dice die1("1d12");
	Dice die2("a12d12");
	Dice die3("b5d12+2");
	std::cout << die1.roll() << ' ' << die2.roll() << " " << die3.roll() <<std::endl;

    FireBow lightMyFire;

    return 0;
}